import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useParams } from 'react-router-dom'
import { editProduct } from './reducer';

function EditData() {
    const products = useSelector(state=>state.productsData)

        const  {id} = useParams();

        const prd = products.filter((product)=>{
           return product.id == id
        })
        const {name,price} = prd[0];

     const [uname,setuName] = useState(name)
      const [uprice,setuPrice] = useState(price)

      const dispatch = useDispatch();
      const handleUpdate = (e)=>{
        e.preventDefault();

        dispatch(editProduct({id:id,uname,uprice}))
      }
  return (
    <div>
       <div className="container-fluid ">
        <div className="row justify-content-center">
          <div className="col-xl-6 text-start">
            <div>
              <h2>Edit Products Details</h2>
              <Link to='/' className="btn btn-info my-3">Home</Link>
            </div>
            <form onSubmit={handleUpdate}>
            <div className="mb-3">
                <label htmlFor="" className="form-label">
                  Name : 
                </label>
                <input
                  type="text"
                  className="form-control"
                  value={uname}
                  onChange={(e)=>{
                    setuName(e.target.value)
                  }}
                 
                />
              </div>
              <div className="mb-3">
                <label htmlFor="" className="form-label">
                  Price 
                </label>
                <input
                  type="text"
                  className="form-control"
                  value={uprice}
                  onChange={(e)=>{
                    setuPrice(e.target.value)
                  }}
                />
              </div>
            
              <button type="submit" className="btn btn-primary">
                Update Product
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}

export default EditData
