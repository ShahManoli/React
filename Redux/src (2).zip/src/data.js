export const products = [
    {id:1,name:"bag","price":300},
    {id:2,name:"shoes","price":500}
] 