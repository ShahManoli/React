import { createSlice } from "@reduxjs/toolkit";
// import { useEffect, useState } from "react";



const userSlice = createSlice({
    name:"Users",
    initialState:[],
    reducers:{
        setData:(state,action)=>{
       
            // return action.payload

            state.push(action.payload)
        },
        addata:(state,action)=>{
           

            fetch('http://localhost:500/data',{
                method:"post",
                headers:{'content-type':'application/json'},
                body:JSON.stringify(action.payload)
            })
           

            state.push(action.payload)
           
        },
        editdata:(state,action)=>{
             console.log(state)
             console.log(action.payload)
              
             
           
            const {id,name,price} = action.payload
            console.log(JSON.stringify({name,price}))

            
             fetch('http://localhost:500/data/' + id,{
                method:"put",
                headers:{'content-type':'application/json'},
                body:JSON.stringify({name,price})
            })

            state.push(action.payload)

         
        },
        deldata : (state,action)=>{
           console.log(state)
           console.log(action.payload)

           const {id} = action.payload

           fetch('http://localhost:500/data/' + id,{
            method:"delete",
            headers:{'content-type':'application/json'},
            
        })


           state.push(action.payload)

        }

    }
})
           
           

           
         
              
            
            



export default userSlice.reducer;
export const { setData , addata , editdata , deldata } = userSlice.actions;