import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { addProduct } from './reducer';
import { useDispatch, useSelector } from 'react-redux';

function AddData() {
const products = useSelector(state=>state.productsData)

    const [name, setName] = useState("");

    const dispatch = useDispatch();
    const handleAdd = (e) => {
        e.preventDefault();
        dispatch(addProduct({id:products.length+1, name}))
    }

    return (
        <div>
            <div className='container'>
                <div className='row justify-content-center'>
                    <div className='col-xl-6'>
                        <div>
                            <Link to="/">Go Back</Link>
                        </div>
                        <form onSubmit={handleAdd}>

                            <div className="mb-3">
                                <label htmlFor="exampleInputPassword1" className="form-label">Name</label>
                                <input type="text" className="form-control"
                                    value={name}
                                    onChange={(e) => {
                                        setName(e.target.value)
                                    }}
                                />
                            </div>
                       
                            <button type="submit" className="btn btn-primary">Add Data</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    )
}

export default AddData
