import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { deleteProduct, DisplayData } from "./reducer";

function Home() {
    const products = useSelector(state => state.productsData)
    const dispatch = useDispatch();

    useEffect(() => {
        if (products == '') { 
        fetch('https://jsonplaceholder.typicode.com/users')
            .then((res) => {return res.json()})
            .then((data)=> {
               dispatch(DisplayData(data));
          })
    }}, [])

    const handleDelete = (id)=>{    
        dispatch(deleteProduct({id}))   
      }

    return (
        <div>
            <div className='container'>
                <div className='row justify-content-center'>
                    <div className='col-xl-6'>
                        <div>
                            <Link to="/add">Add data</Link>
                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                   
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {products.map((value) => (
                                    <tr key={value.id}>
                                        <td>{value.id}</td>
                                        <td>{value.name}</td>                                    
                                        <td>
                                            <Link to={'/edit/' + value.id} className="btn btn-success">Edit</Link>
                                            <button onClick={() => { handleDelete(value.id) }} className="btn btn-danger ms-2">Delete</button>
                                        </td>
                                    </tr>
                                ))}

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Home
