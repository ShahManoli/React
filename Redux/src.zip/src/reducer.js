import { createSlice } from "@reduxjs/toolkit";

const productSlice = createSlice({
    name: "Products",
    initialState: [],
    reducers: {
        DisplayData:(state,action)=>{    
            return action.payload
            // state.push(action.payload)
        },

        addProduct: (state, action) => {
            state.push(action.payload)
        },

        deleteProduct:(state,action)=>{
            const {id} = action.payload
           const product =  state.find((product)=>{
                return product.id == id
            })
            if(product)
            {
                return state.filter(product=> product.id!==id)
            }
        },

        editProduct:(state,action)=>{
            const {id,uname} = action.payload
            const product =    state.find((product)=>{
                    return product.id == id
                })
                if(product)
                {
                   product.name = uname;
                }
        }

    }
})

export const {addProduct, deleteProduct, editProduct, DisplayData} = productSlice.actions
export default productSlice.reducer;