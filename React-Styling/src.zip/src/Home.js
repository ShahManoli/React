import React from 'react'

function Home() {
  const xyz= {
    backgroundColor:"black",
    color:"white",
    border:"3px solid blue"
  }
  return (
   <>
   <h1 className='mt-5' style={xyz}>Home Page</h1>
   </>
  )
}

export default Home