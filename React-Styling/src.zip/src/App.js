import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Link, Route, Router, Routes } from 'react-router-dom';
import Home from './Home';
import   "../node_modules/bootstrap/dist/css/bootstrap.css"
import Contact from './Contact';

function App() {
  return (
    <div className="App">
<Home/>
<Contact/>
    </div>
  );
}

export default App;
