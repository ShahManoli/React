import { createSlice } from "@reduxjs/toolkit";
import { products } from "./data";

const productSlice = createSlice({
    name: "Products",
    initialState: products,
    reducers: {
        addProduct: (state, action) => {
            // console.log(state)
            // console.log(action.payload)
            state.push(action.payload)
        },

        deleteProduct:(state,action)=>{
            const {id} = action.payload
           const product =  state.find((product)=>{
                return product.id == id
            })
            if(product)
            {
                return state.filter(product=> product.id!==id)
            }
        },

        editProduct:(state,action)=>{
            console.log(action.payload)
            const {id,uname,uprice} = action.payload
            const product =    state.find((product)=>{
                    return product.id == id
                })
                if(product)
                {
                   product.name = uname;
                   product.price = uprice;
                }
        }

    }
})

export const {addProduct, deleteProduct, editProduct} = productSlice.actions
export default productSlice.reducer;