import React, { useEffect, useState } from 'react'

function UseState() {

    const [state,setState] = useState(1)
  return (
    <>
      <h3>{state}</h3>
      <button style={{width:"100px",fontSize:"20px"}} onClick={()=>{setState(state + 1)}}>+</button>
      <UseeffectHook></UseeffectHook>
    </>
  )
}

export default UseState

function UseeffectHook()
{

    const [data,setData] = useState([])

    useEffect(()=>{
        fetch('https://jsonplaceholder.typicode.com/users')
        .then((res)=>{return res.json()})
        .then((data)=>{
             console.log(data)
             setData(data)
        })
    },[])
    return(
        <>
        <h3>Use Effect </h3>
             {data.map((v)=>(
                <li style={{listStyle:'none', lineHeight:'30px'}}>{v.id} {" "} {v.name}</li>
             ))}
        </>
    )
}