import logo from './logo.svg';
import './App.css';
import Lists from './Lists';
import UseState from './UseState';

function App() {
  return (
    <div className="App">
      <Lists/>
      <UseState/>
    </div>
  );
}

export default App;
