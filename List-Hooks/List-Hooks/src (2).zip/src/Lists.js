import React from "react";

export default class Lists extends React.Component
{
    arr = [{fruit:"Apple"},
        {fruit:"Mango"},
        {fruit:"Watermelon"},
        {fruit:"Kivi"}
    ]
  render()
  {
    return(
        <>
        <h1>Lists and Keys</h1>
          {this.arr.map((v)=>(
           <li key={v.id}>
            {v.fruit}
            </li>
          )
        
          )}
        </>
    )
  }
}