import logo from './logo.svg';
import './App.css';
import Accordian from './Accordian';
import "../node_modules/bootstrap/dist/css/bootstrap.css"

function App() {
  return (
    <div className="App">
     <Accordian/>
    </div>
  );
}

export default App;
